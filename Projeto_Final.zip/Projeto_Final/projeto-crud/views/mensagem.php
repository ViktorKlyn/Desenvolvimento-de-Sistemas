<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Mensagem</title>
  <link href="../public/./css/./css/./bootstrap.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <div class="alert alert-info text-center">
    <?= $mensagem ?>
  </div>
  <a href="index.php?acao=listar" class="btn btn-secondary">Voltar</a>
</body>
</html>