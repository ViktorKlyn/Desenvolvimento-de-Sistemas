<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Lista de Filmes</title>
  <link href="../public/./css/./css/./bootstrap.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h2>Lista de Filmes</h2>
  
  <a href="index.php?acao=cadastrar" class="btn btn-success mb-3">+ Novo Filme</a>
  
  <table class="table table-striped table-hover">
    <thead class="table-dark">
      <tr>
        <th>ID</th><th>Título</th><th>Diretor</th><th>Ano</th><th>Gênero</th><th>Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($filmes as $f): ?>
      <tr>
        <td><?= $f['id'] ?></td>
        <td><?= $f['titulo'] ?></td>
        <td><?= $f['diretor'] ?></td>
        <td><?= $f['ano'] ?></td>
        <td><?= $f['genero'] ?></td>
        <td>
          <a href="index.php?acao=editar&id=<?= $f['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
          <a href="index.php?acao=excluir&id=<?= $f['id'] ?>" class="btn btn-danger btn-sm">Excluir</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</body>
</html>