<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastrar Filme</title>
  <link href="../public/./css/./css/./bootstrap.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h2>Cadastrar Filme</h2>
  
  <form method="POST">
    <div class="mb-3">
      <input type="text" name="titulo" class="form-control" placeholder="Título" required>
    </div>
    <div class="mb-3">
      <input type="text" name="diretor" class="form-control" placeholder="Diretor" required>
    </div>
    <div class="mb-3">
      <input type="number" name="ano" class="form-control" placeholder="Ano" required>
    </div>
    <div class="mb-3">
      <input type="text" name="genero" class="form-control" placeholder="Gênero">
    </div>
    <button type="submit" class="btn btn-primary">Salvar</button>
    <a href="index.php?acao=listar" class="btn btn-secondary">Voltar</a>
  </form>
</body>
</html>