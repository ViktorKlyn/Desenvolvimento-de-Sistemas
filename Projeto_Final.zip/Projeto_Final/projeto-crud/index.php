<?php
require_once "controllers/FilmeController.php";
$controller = new FilmeController();
$acao = $_GET['acao'] ?? 'listar';
$id = $_GET['id'] ?? null;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastro de Filmes</title>
  <link href="./public/./css/./css/./bootstrap.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">🎬 Cadastro de Filmes</a>
    <div>
      <a class="btn btn-outline-light me-2 <?= ($acao=='listar')?'active':'' ?>" href="index.php?acao=listar">Listar</a>
      <a class="btn btn-outline-light <?= ($acao=='cadastrar')?'active':'' ?>" href="index.php?acao=cadastrar">Cadastrar</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <?php
    switch ($acao) {
      case 'cadastrar': $controller->cadastrar(); break;
      case 'editar':    if ($id) $controller->editar($id); break;
      case 'excluir':   if ($id) $controller->excluir($id); break;
      default:          $controller->listar(); break;
    }
  ?>
</div>
</body>
</html>