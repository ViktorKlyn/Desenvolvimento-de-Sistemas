<?php
require_once "config/Database.php";

$pdo = Database::connect();

if ($pdo) {
    echo "Conexão realizada com sucesso!";
}
?>
