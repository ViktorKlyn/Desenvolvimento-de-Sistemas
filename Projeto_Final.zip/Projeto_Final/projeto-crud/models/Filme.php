<?php

require_once "config/Database.php";

class Filme {

    public static function listar() {
        $pdo = Database::connect();
        return $pdo->query("SELECT * FROM filmes")->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function cadastrar($titulo, $diretor, $ano, $genero) {
        $pdo = Database::connect();
        $sql = "INSERT INTO filmes (titulo, diretor, ano, genero) VALUES (?, ?, ?, ?)";
        return $pdo->prepare($sql)->execute([$titulo, $diretor, $ano, $genero]);
    }

    public static function buscarPorId($id) {
        $pdo = Database::connect();
        $sql = "SELECT * FROM filmes WHERE id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function atualizar($id, $titulo, $diretor, $ano, $genero) {
        $pdo = Database::connect();
        $sql = "UPDATE filmes SET titulo=?, diretor=?, ano=?, genero=? WHERE id=?";
        return $pdo->prepare($sql)->execute([$titulo, $diretor, $ano, $genero, $id]);
    }

    public static function excluir($id) {
        $pdo = Database::connect();
        $sql = "DELETE FROM filmes WHERE id=?";
        return $pdo->prepare($sql)->execute([$id]);
    }
}

?>