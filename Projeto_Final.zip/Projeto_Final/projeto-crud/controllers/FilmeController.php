<?php
require_once "models/Filme.php";

class FilmeController {

    public function listar() {
        $filmes = Filme::listar();
        include "views/listar.php";
    }

    public function cadastrar() {
        if ($_POST) {
            $ok = Filme::cadastrar($_POST['titulo'], $_POST['diretor'], $_POST['ano'], $_POST['genero']);
            $mensagem = $ok ? "Filme cadastrado com sucesso!" : "Erro ao cadastrar.";
            include "views/mensagem.php";
        } else {
            include "views/cadastrar.php";
        }
    }

    public function editar($id) {
        if ($_POST) {
            $ok = Filme::atualizar($id, $_POST['titulo'], $_POST['diretor'], $_POST['ano'], $_POST['genero']);
            $mensagem = $ok ? "Filme atualizado com sucesso!" : "Erro ao atualizar.";
            include "views/mensagem.php";
        } else {
            $filme = Filme::buscarPorId($id);
            include "views/editar.php";
        }
    }

    public function excluir($id) {
        $ok = Filme::excluir($id);
        $mensagem = $ok ? "Filme excluído com sucesso!" : "Erro ao excluir.";
        include "views/mensagem.php";
    }
}
?>