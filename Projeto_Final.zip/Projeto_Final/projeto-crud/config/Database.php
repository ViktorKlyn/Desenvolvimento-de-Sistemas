<?php
class Database {
    private static $host = "localhost";
    private static $dbname = "cadastrar_filme"; 
    private static $user = "root";  
    private static $pass = "";        

    public static function connect() {
        try {
            // Cria a conexão PDO
            $pdo = new PDO("mysql:host=".self::$host.";dbname=".self::$dbname, self::$user, self::$pass);
            // Ativa mensagens de erro
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (PDOException $e) {
            // Mostra erro se não conectar
            die("Erro: " . $e->getMessage());
        }
    }
}
?>